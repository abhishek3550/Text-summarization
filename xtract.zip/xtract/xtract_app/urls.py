from django.urls import path
from . import views

urlpatterns = [
    path('register/', views.register, name='register'),
    path('login/', views.login, name='login'),
    path('selection/', views.selection, name='selection'),
    path('summary/', views.summary, name='summary'),
    path('translation/<summary>', views.translation, name='translation'),
    path('voice/<text>/<lang>', views.voice, name='voice'),
    path('download/<text>/<lang>/<length>', views.download, name='download'),
]
