import os
from django.conf import settings
from django.http import HttpResponse, HttpResponseRedirect
from django.shortcuts import render, redirect
from django.contrib import messages
import pyttsx3
from gtts import gTTS
from playsound import  playsound
from googletrans import Translator
# from django.template.loader import render_to_string
# from .utils import html_to_pdf
from django.template.loader import get_template
from xhtml2pdf import pisa
import pdfkit
from .apps import SummarizorConfig, SentimentConfig

# Create your views here.
LANGUAGES = {
    'af': 'afrikaans',
    'sq': 'albanian',
    'am': 'amharic',
    'ar': 'arabic',
    'hy': 'armenian',
    'az': 'azerbaijani',
    'eu': 'basque',
    'be': 'belarusian',
    'bn': 'bengali',
    'bs': 'bosnian',
    'bg': 'bulgarian',
    'ca': 'catalan',
    'ceb': 'cebuano',
    'ny': 'chichewa',
    'zh-cn': 'chinese (simplified)',
    'zh-tw': 'chinese (traditional)',
    'co': 'corsican',
    'hr': 'croatian',
    'cs': 'czech',
    'da': 'danish',
    'nl': 'dutch',
    'en': 'english',
    'eo': 'esperanto',
    'et': 'estonian',
    'tl': 'filipino',
    'fi': 'finnish',
    'fr': 'french',
    'fy': 'frisian',
    'gl': 'galician',
    'ka': 'georgian',
    'de': 'german',
    'el': 'greek',
    'gu': 'gujarati',
    'ht': 'haitian creole',
    'ha': 'hausa',
    'haw': 'hawaiian',
    'iw': 'hebrew',
    'he': 'hebrew',
    'hi': 'hindi',
    'hmn': 'hmong',
    'hu': 'hungarian',
    'is': 'icelandic',
    'ig': 'igbo',
    'id': 'indonesian',
    'ga': 'irish',
    'it': 'italian',
    'ja': 'japanese',
    'jw': 'javanese',
    'kn': 'kannada',
    'kk': 'kazakh',
    'km': 'khmer',
    'ko': 'korean',
    'ku': 'kurdish (kurmanji)',
    'ky': 'kyrgyz',
    'lo': 'lao',
    'la': 'latin',
    'lv': 'latvian',
    'lt': 'lithuanian',
    'lb': 'luxembourgish',
    'mk': 'macedonian',
    'mg': 'malagasy',
    'ms': 'malay',
    'ml': 'malayalam',
    'mt': 'maltese',
    'mi': 'maori',
    'mr': 'marathi',
    'mn': 'mongolian',
    'my': 'myanmar (burmese)',
    'ne': 'nepali',
    'no': 'norwegian',
    'or': 'odia',
    'ps': 'pashto',
    'fa': 'persian',
    'pl': 'polish',
    'pt': 'portuguese',
    'pa': 'punjabi',
    'ro': 'romanian',
    'ru': 'russian',
    'sm': 'samoan',
    'gd': 'scots gaelic',
    'sr': 'serbian',
    'st': 'sesotho',
    'sn': 'shona',
    'sd': 'sindhi',
    'si': 'sinhala',
    'sk': 'slovak',
    'sl': 'slovenian',
    'so': 'somali',
    'es': 'spanish',
    'su': 'sundanese',
    'sw': 'swahili',
    'sv': 'swedish',
    'tg': 'tajik',
    'ta': 'tamil',
    'te': 'telugu',
    'th': 'thai',
    'tr': 'turkish',
    'uk': 'ukrainian',
    'ur': 'urdu',
    'ug': 'uyghur',
    'uz': 'uzbek',
    'vi': 'vietnamese',
    'cy': 'welsh',
    'xh': 'xhosa',
    'yi': 'yiddish',
    'yo': 'yoruba',
    'zu': 'zulu',
}

def home(request):
    return render(request, 'home_page/home.html')


def register(request):
    return render(request, 'home_page/register.html')


def login(request):
    return render(request, 'home_page/login.html')


def selection(request):
    return render(request, 'home_page/selection.html')


def summary(request):

    if request.method == 'POST':
        text = request.POST['text']

    min_length = int((15 * len(text.split(' '))) / 100)
    max_length = int((40 * len(text.split(' '))) / 100)

    summarizer = SummarizorConfig.summarizer
    summary = summarizer(text)
    # summary = summarizer(text, max_length=max_length,
    #                      min_length=min_length, do_sample=False)

    sid = SentimentConfig.sid
    dic = sid.polarity_scores(summary[0]['summary_text'])
    value = dic['compound']
    pos = 'The Summary is Positive'
    neu = 'The Summary is Neutral'
    neg = 'The Summary is Negative'
    ans = pos if value > 0.3 else neu if -0.3 < value < 0.3 else neg

    messages.success(request, 'Text Summarized Successful ! ! ! !')

    engine = pyttsx3.init()
    engine.say(ans)
    engine.runAndWait()

    context = {
        'text': text,
        'length_text': len(text),
        'summary': summary[0]['summary_text'],
        'length_summary': len(summary[0]['summary_text']),
        'sentiment': ans,
        'languages' : LANGUAGES
    }

    return render(request, 'home_page/summary.html', context=context)

def translation(request, summary):

    if request.method == 'POST':
        dest_lang = request.POST['dest_lang']

    translator = Translator()
    result = translator.translate(summary, src='en', dest=str(dest_lang))

    # print('Auto Detected Source Language : ', result.src)
    # print('Destination Language : ', result.dest)
    # print('Translated Text : ', result.text)
    src = result.src
    dest = result.dest
    res = result.text

    context = {
        'src_lang': LANGUAGES[src],
        'dest_lang': LANGUAGES[dest],
        'res': res,
        'summary': summary,
        'length_summary': len(summary),
        'length_trans' : len(res),
        'src' : src,
        'dest' : dest
    }

    return render(request, 'home_page/translation.html', context=context)

def voice(request, text, lang):

    path = os.path.join(settings.AUDIO, 'sounds.mp3')
    output = gTTS(text=text, lang=lang)
    output.save(path)
    playsound(path)
    os.remove(path)

    return HttpResponseRedirect('/xtract_app/translation/')

def download(request, text, lang, length):
    # get the template for the PDF
    template = get_template('home_page/temp_pdf.html')
    
    # get the context for the template
    context = {
        'text' : text,
        'lang' : lang,
        'length' : length
    }
    
    # render the template with the context
    html = template.render(context)
    
    # create a PDF file using the HTML
    pdf_file = open('output.pdf', 'w+b')
    pisa.CreatePDF(html.encode('utf-8'), dest=pdf_file, encoding="utf-8")
    pdf_file.seek(0)
    
    # return the PDF file as a response
    response = HttpResponse(pdf_file, content_type='application/pdf')
    file_name = f'summary_{lang}.pdf'
    response['Content-Disposition'] = 'attachment; filename='+file_name
    
    return response
