# Importing the required libraries
import nltk
nltk.download('vader_lexicon')
from nltk.sentiment.vader import SentimentIntensityAnalyzer
import pickle

# Creating sentiment analysis model
sid = SentimentIntensityAnalyzer()

# Converting the model to .p file
my_var = {
    'sid': sid
}
pickle.dump( my_var, open( 'sentiment' + ".p", "wb" ) )