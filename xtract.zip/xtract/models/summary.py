# Importing the libraries
from transformers import pipeline
import pickle

# Loading the summarization pipeline
summarizer = pipeline('summarization')

# Converting the model to .p file
my_var = {
    'summarizer': summarizer
}
pickle.dump( my_var, open( 'summary' + ".p", "wb" ) )